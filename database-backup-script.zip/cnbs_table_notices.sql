
-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `notice_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `content` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `priority` enum('High','Medium','Low') DEFAULT 'Low',
  `user_id` int(11) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `views` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`notice_id`, `title`, `content`, `category_id`, `priority`, `user_id`, `expiry_date`, `views`, `created_at`) VALUES
(1, 'Community Cleanup Day', 'Join us this Saturday for cleanup.', 1, 'Medium', 1, '2026-01-15', 0, '2026-01-05 23:35:48'),
(2, 'Health Awareness Talk', 'Free health screening and talk at the community hall.', 1, 'Low', 1, '2026-01-20', 0, '2026-01-05 23:35:48'),
(3, 'Sports Day Registration', 'Register now for the annual sports day.', 1, 'Medium', 1, '2026-01-25', 0, '2026-01-05 23:35:48'),
(4, 'Water Supply Disruption', 'Emergency maintenance tonight.', 2, 'High', 1, '2026-01-08', 0, '2026-01-05 23:35:48'),
(5, 'Gas Leak Reported', 'Residents advised to evacuate Block B immediately.', 2, 'High', 1, '2026-01-06', 0, '2026-01-05 23:35:48'),
(6, 'Flood Warning', 'Heavy rain expected. Please stay alert.', 2, 'High', 1, '2026-01-07', 0, '2026-01-05 23:35:48'),
(7, 'Elevator Maintenance', 'Elevator will be unavailable from 9AM to 5PM.', 3, 'Medium', 1, '2026-01-10', 0, '2026-01-05 23:35:48'),
(8, 'Internet Service Downtime', 'Internet will be temporarily unavailable.', 3, 'Low', 1, '2026-01-12', 0, '2026-01-05 23:35:48'),
(9, 'Office Closed on Public Holiday', 'Office will be closed next Monday.', 4, 'Low', 1, '2026-01-17', 0, '2026-01-05 23:35:48'),
(10, 'New Parking Rules', 'Please follow updated parking guidelines.', 4, 'Medium', 1, '2026-02-04', 0, '2026-01-05 23:35:48'),
(11, 'Old Announcement', 'This notice is expired.', 4, 'Low', 1, '2026-01-03', 0, '2026-01-05 23:35:48'),
(12, 'Community Cleanup Day', 'Join us this Saturday for cleanup.', 1, 'Medium', 1, '2026-01-15', 0, '2026-01-05 23:38:38'),
(13, 'Health Awareness Talk', 'Free health screening and talk at the community hall.', 1, 'Low', 1, '2026-01-20', 0, '2026-01-05 23:38:38'),
(14, 'Sports Day Registration', 'Register now for the annual sports day.', 1, 'Medium', 1, '2026-01-25', 0, '2026-01-05 23:38:38'),
(15, 'Water Supply Disruption', 'Emergency maintenance tonight.', 2, 'High', 1, '2026-01-08', 0, '2026-01-05 23:38:38'),
(16, 'Gas Leak Reported', 'Residents advised to evacuate Block B immediately.', 2, 'High', 1, '2026-01-06', 0, '2026-01-05 23:38:38'),
(17, 'Flood Warning', 'Heavy rain expected. Please stay alert.', 2, 'High', 1, '2026-01-07', 0, '2026-01-05 23:38:38'),
(18, 'Elevator Maintenance', 'Elevator will be unavailable from 9AM to 5PM.', 3, 'Medium', 1, '2026-01-10', 0, '2026-01-05 23:38:38'),
(19, 'Internet Service Downtime', 'Internet will be temporarily unavailable.', 3, 'Low', 1, '2026-01-12', 0, '2026-01-05 23:38:38'),
(20, 'Office Closed on Public Holiday', 'Office will be closed next Monday.', 4, 'Low', 1, '2026-01-17', 0, '2026-01-05 23:38:38'),
(21, 'New Parking Rules', 'Please follow updated parking guidelines.', 4, 'Medium', 1, '2026-02-04', 0, '2026-01-05 23:38:38'),
(22, 'Old Announcement', 'This notice is expired.', 4, 'Low', 1, '2026-01-03', 0, '2026-01-05 23:38:38');
