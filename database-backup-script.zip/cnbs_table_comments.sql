
-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `notice_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `notice_id`, `user_id`, `content`, `image_path`, `status`, `created_at`) VALUES
(1, 1, 2, 'I will be joining with my family.', 'uploads/comments/comment_1_1_2.jpg', 'approved', '2026-01-05 23:38:38'),
(2, 1, 3, 'What time does the event start?', NULL, 'pending', '2026-01-05 23:38:38'),
(3, 2, 1, 'Is registration required?', NULL, 'pending', '2026-01-05 23:38:38'),
(4, 3, 2, 'Can teenagers participate?', NULL, 'approved', '2026-01-05 23:38:38'),
(5, 3, 3, 'Looking forward to this event!', 'uploads/comments/comment_5_3_3.jpg', 'approved', '2026-01-05 23:38:38'),
(6, 4, 2, 'Will water be restored by morning?', NULL, 'approved', '2026-01-05 23:38:38'),
(7, 4, 3, 'Thanks for the early notice.', NULL, 'approved', '2026-01-05 23:38:38'),
(8, 5, 2, 'Emergency services are already on site.', NULL, 'approved', '2026-01-05 23:38:38'),
(9, 5, 3, 'Hope everyone is safe.', NULL, 'approved', '2026-01-05 23:38:38'),
(10, 6, 1, 'Please avoid unnecessary travel.', NULL, 'approved', '2026-01-05 23:38:38'),
(11, 7, 3, 'Will the stairs be accessible?', NULL, 'pending', '2026-01-05 23:38:38'),
(12, 8, 2, 'Thanks for informing us early.', NULL, 'approved', '2026-01-05 23:38:38'),
(13, 9, 3, 'Does this include customer support?', NULL, 'pending', '2026-01-05 23:38:38'),
(14, 10, 2, 'Where can we find the full guidelines?', NULL, 'approved', '2026-01-05 23:38:38'),
(15, 11, 1, 'This announcement is no longer relevant.', NULL, 'rejected', '2026-01-05 23:38:38');
