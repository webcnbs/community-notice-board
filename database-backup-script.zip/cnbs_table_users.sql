
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('resident','manager','admin') DEFAULT 'resident',
  `status` enum('pending','active','disabled') DEFAULT 'pending',
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `role`, `status`, `remember_token`, `created_at`) VALUES
(1, 'admin', 'admin@cnbs.local', '$2y$10$wH8YxLq6U7ZQnN9V4Jc8nOZq1YxY9WQFJQX1rJwFJQxY9Y0pYFZ6', 'admin', 'active', NULL, '2026-01-05 23:35:06'),
(2, 'manager1', 'manager1@example.com', '$2y$10$wH8YxLq6U7ZQnN9V4Jc8nOZq1YxY9WQFJQX1rJwFJQxY9Y0pYFZ6', 'manager', 'active', NULL, '2026-01-05 23:35:06'),
(3, 'resident1', 'resident1@example.com', '$2y$10$wH8YxLq6U7ZQnN9V4Jc8nOZq1YxY9WQFJQX1rJwFJQxY9Y0pYFZ6', 'resident', 'active', NULL, '2026-01-05 23:35:06'),
(4, 'resident2', 'resident2@example.com', '$2y$10$wH8YxLq6U7ZQnN9V4Jc8nOZq1YxY9WQFJQX1rJwFJQxY9Y0pYFZ6', 'resident', 'pending', NULL, '2026-01-05 23:35:06'),
(5, 'resident3', 'resident3@example.com', '$2y$10$wH8YxLq6U7ZQnN9V4Jc8nOZq1YxY9WQFJQX1rJwFJQxY9Y0pYFZ6', 'resident', 'disabled', NULL, '2026-01-05 23:35:06');
