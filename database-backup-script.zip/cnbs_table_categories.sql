
-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `color_code` varchar(7) DEFAULT '#888888'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `description`, `color_code`) VALUES
(1, 'Events', 'Community events and activities', '#2E86C1'),
(2, 'Emergencies', 'Urgent notices', '#C0392B'),
(3, 'Maintenance', 'Scheduled maintenance updates', '#27AE60'),
(4, 'General', 'General information', '#7D3C98');
